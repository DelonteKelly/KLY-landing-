
const { ThirdwebSDK } = thirdweb;

const CONFIG = {
  chain: "binance",
  contracts: {
    KLY_TOKEN: "0x2e4fEB2Fe668c8Ebe84f19e6c8fE8Cf8131B4E52",
    STAKING: "0x25548Ba29a0071F30E4bDCd98Ea72F79341b07a1"
  },
  gasOptions: {
    gasLimit: 300000
  }
};

const state = {
  sdk: null,
  wallet: null,
  contracts: {
    token: null,
    staking: null
  },
  transactionInProgress: false
};

async function initApp() {
  try {
    state.sdk = new ThirdwebSDK(CONFIG.chain);
    setupEventListeners();
    if (window.ethereum?.selectedAddress) {
      await connectWallet();
    }
    console.log("DApp initialized successfully");
  } catch (error) {
    console.error("Initialization error:", error);
    showStatus("Failed to initialize DApp", true);
  }
}

async function connectWallet() {
  if (state.transactionInProgress) return;
  try {
    setLoadingState(true);
    showStatus("Connecting wallet...");
    if (!window.ethereum) throw new Error("Please install MetaMask");
    state.wallet = await state.sdk.wallet.connect("injected");
    const address = await state.wallet.getAddress();
    state.contracts.token = await state.sdk.getContract(CONFIG.contracts.KLY_TOKEN, "token");
    state.contracts.staking = await state.sdk.getContract(CONFIG.contracts.STAKING);
    updateWalletInfo(address);
    updateTokenInfo();
    showStatus(`Connected: ${shortenAddress(address)}`);
  } catch (error) {
    console.error("Wallet connection failed:", error);
    showStatus(`Connection failed: ${error.message}`, true);
  } finally {
    setLoadingState(false);
  }
}

async function stakeTokens() {
  const amount = document.getElementById("stakeAmount").value;
  if (!state.wallet || parseFloat(amount) <= 0) return showStatus("Invalid amount", true);
  try {
    setLoadingState(true);
    await state.contracts.token.setAllowance(CONFIG.contracts.STAKING, amount);
    await state.contracts.staking.call("stake", [amount], CONFIG.gasOptions);
    showStatus(`${amount} KLY staked!`);
    updateTokenInfo();
    document.getElementById("stakeAmount").value = "";
  } catch (err) {
    console.error(err);
    showStatus("Stake failed", true);
  } finally {
    setLoadingState(false);
  }
}

async function claimRewards() {
  try {
    setLoadingState(true);
    await state.contracts.staking.call("claimRewards", [], CONFIG.gasOptions);
    showStatus("Rewards claimed!");
  } catch (err) {
    console.error(err);
    showStatus("Claim failed", true);
  } finally {
    setLoadingState(false);
  }
}

async function withdrawTokens() {
  try {
    setLoadingState(true);
    await state.contracts.staking.call("withdraw", [], CONFIG.gasOptions);
    showStatus("Withdrawn!");
  } catch (err) {
    console.error(err);
    showStatus("Withdraw failed", true);
  } finally {
    setLoadingState(false);
  }
}

async function launchToken() {
  const name = document.getElementById("tokenName").value;
  const symbol = document.getElementById("tokenSymbol").value;
  const supply = document.getElementById("tokenSupply").value;
  if (!name || !symbol || parseFloat(supply) <= 0) return showStatus("Invalid token data", true);
  try {
    setLoadingState(true);
    await state.sdk.deployer.deployToken({
      name,
      symbol,
      primary_sale_recipient: await state.wallet.getAddress(),
      initial_supply: supply
    });
    showStatus(`Launched ${name} (${symbol})`);
  } catch (err) {
    console.error(err);
    showStatus("Token launch failed", true);
  } finally {
    setLoadingState(false);
  }
}

async function updateTokenInfo() {
  if (!state.wallet) return;
  const address = await state.wallet.getAddress();
  const [totalSupply, balance] = await Promise.all([
    state.contracts.token.totalSupply(),
    state.contracts.token.balanceOf(address)
  ]);
  document.getElementById("total-supply").textContent = totalSupply.displayValue;
  document.getElementById("user-balance").textContent = balance.displayValue;
}

function setupEventListeners() {
  document.getElementById("connectWallet").onclick = connectWallet;
  document.getElementById("stakeButton").onclick = stakeTokens;
  document.getElementById("claimButton").onclick = claimRewards;
  document.getElementById("withdrawButton").onclick = withdrawTokens;
  document.getElementById("launchToken").onclick = launchToken;
  document.getElementById("startCourse").onclick = () => window.location.href = "/course.html";
}

function showStatus(msg, isError = false) {
  let el = document.getElementById("transaction-status");
  if (!el) {
    el = document.createElement("div");
    el.id = "transaction-status";
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.className = isError ? "status-error" : "status-success";
  setTimeout(() => el.textContent = "", 5000);
}

function updateWalletInfo(addr) {
  const btn = document.getElementById("connectWallet");
  btn.textContent = shortenAddress(addr);
}

function setLoadingState(isLoading) {
  state.transactionInProgress = isLoading;
  document.querySelectorAll("button").forEach(b => b.disabled = isLoading);
  document.body.style.cursor = isLoading ? "wait" : "default";
}

function shortenAddress(a) {
  return a ? `${a.slice(0, 6)}...${a.slice(-4)}` : "";
}

window.addEventListener("DOMContentLoaded", initApp);
